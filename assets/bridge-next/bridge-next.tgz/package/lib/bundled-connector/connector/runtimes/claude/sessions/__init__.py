"""Claude session cache helpers."""
