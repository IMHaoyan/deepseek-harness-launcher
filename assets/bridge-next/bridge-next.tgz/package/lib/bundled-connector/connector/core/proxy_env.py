"""Keep ``NO_PROXY`` parseable for httpx.

httpx builds its proxy-bypass table by turning every ``NO_PROXY`` entry into a
URL pattern. Entries it cannot classify as IPv4/IPv6/localhost fall through to
its wildcard-host branch, so a bracketed IPv6 literal such as ``[::1]`` becomes
the malformed pattern ``all://*[::1]`` and merely *constructing* a client raises
``httpx.InvalidURL: Invalid port: ':1]'``. Clash Verge / mihomo writes exactly
that bracketed form into ``NO_PROXY``, which made the connector unable to start
at all (the process came up, then died before its first request).

We do not reimplement proxy selection; we only hand httpx entries it can parse.
The rewrite is scoped to client construction — httpx reads these variables there
and nowhere else — and the original values are restored immediately afterwards,
so child processes this connector spawns keep seeing the environment their
launcher provided.
"""

from __future__ import annotations

import ipaddress
import os
import re
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any

import httpx

from connector.logging import logger

PROXY_ENV_NAMES = ("NO_PROXY", "no_proxy")

# "[::1]" / "[2001:db8::1]:8080" — the bracketed form other tools write and the
# one httpx misclassifies.
_BRACKETED_ENTRY = re.compile(r"^\[(?P<host>[^\]]+)\](?::(?P<port>\d+))?$")


def _proxy_env_names() -> tuple[str, ...]:
    """Environment names to rewrite.

    ``os.environ`` is case-insensitive on Windows, where both spellings name the
    same variable; POSIX keeps them separate and urllib honours both.
    """
    if os.name == "nt":
        return ("NO_PROXY",)
    return PROXY_ENV_NAMES


def normalize_no_proxy(value: str) -> tuple[str, list[str]]:
    """Return ``(normalized, dropped)`` for one ``NO_PROXY`` value."""
    kept: list[str] = []
    dropped: list[str] = []
    for raw in value.split(","):
        entry = raw.strip()
        if not entry:
            continue
        normalized = _normalize_entry(entry)
        if normalized is None:
            dropped.append(entry)
        else:
            kept.append(normalized)
    return ",".join(kept), dropped


def _normalize_entry(entry: str) -> str | None:
    """Return a form httpx classifies correctly, or ``None`` to drop the entry."""
    if entry == "*":
        # httpx short-circuits on "*" and ignores every proxy.
        return entry

    bracketed = _BRACKETED_ENTRY.match(entry)
    if bracketed:
        # httpx's IPv6 branch keys on the bare address and ignores a port, so the
        # port is dropped rather than kept as an unparseable suffix.
        return bracketed.group("host")

    if ":" not in entry:
        return entry

    try:
        ipaddress.IPv6Address(entry)
    except ValueError:
        pass
    else:
        return entry

    # "host:port" is parsed by httpx; anything else would reach the wildcard
    # branch and raise while the pattern is being built.
    host, _, port = entry.rpartition(":")
    if host and port.isdigit():
        return entry
    return None


@contextmanager
def httpx_safe_proxy_environment() -> Iterator[None]:
    """Expose rewritten ``NO_PROXY`` values to httpx, then restore the originals."""
    original = {name: os.environ.get(name) for name in _proxy_env_names()}
    rewritten: list[str] = []
    try:
        for name, value in original.items():
            if not value:
                continue
            normalized, dropped = normalize_no_proxy(value)
            if dropped:
                logger.warning(
                    "ignoring {} entries httpx cannot parse: {}",
                    name,
                    ",".join(dropped),
                )
            if normalized != value:
                os.environ[name] = normalized
                rewritten.append(name)
                logger.debug(
                    "normalized {} for httpx: {!r} -> {!r}", name, value, normalized
                )
        yield
    finally:
        for name in rewritten:
            value = original[name]
            if value is None:
                os.environ.pop(name, None)
            else:
                os.environ[name] = value


def create_http_client(**kwargs: Any) -> httpx.AsyncClient:
    """Build an ``httpx.AsyncClient`` that tolerates ``[::1]``-style NO_PROXY entries."""
    with httpx_safe_proxy_environment():
        return httpx.AsyncClient(**kwargs)
